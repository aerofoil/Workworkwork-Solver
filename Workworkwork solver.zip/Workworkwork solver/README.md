# Workworkwork-Solver
A tool to automatically solve workworkwork puzzles.
Currently only works for levels using mechanics from chapters 1 to 4.
