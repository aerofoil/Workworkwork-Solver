from math import pi
from rotatepiece import rotatepiece
from copy import deepcopy
def checkpiece(output,puzzleoutput) -> bool:
    output = {cell:output[cell] for cell in output if output[cell] != (0,0)}
    #puzzleoutput = {cell:puzzleoutput[cell] for cell in puzzleoutput if puzzleoutput[cell] != (0,0)}
    if len(output) == 0:
        return True
    if len(puzzleoutput) == 0:
        return False
    puzzleoutputdimensions = (max(puzzleoutput)[0]-min(puzzleoutput)[0],max([cell[1] for cell in puzzleoutput])-min([cell[1] for cell in puzzleoutput]))
    outputdimensionsoffset = (0-min(output)[0],0-min([cell[1] for cell in output]))
    puzzleoutputdimensionsoffset = (0-min(puzzleoutput)[0],0-min([cell[1] for cell in puzzleoutput]))
    puzzleoutput = {(cell[0]+puzzleoutputdimensionsoffset[0],cell[1]+puzzleoutputdimensionsoffset[1]):puzzleoutput[cell] for cell in puzzleoutput}
    for _ in range(4):
        output = rotatepiece(output.keys(),output,pi/2,(0,0))[1]
        outputdimensionsoffset = (0-min(output)[0],0-min([cell[1] for cell in output]))
        output = {(cell[0]+outputdimensionsoffset[0],cell[1]+outputdimensionsoffset[1]):output[cell] for cell in output}
        outputdimensions = (max(output)[0]-min(output)[0],max([cell[1] for cell in output])-min([cell[1] for cell in output]))
        if outputdimensions[0] > puzzleoutputdimensions[0] or outputdimensions[1] > puzzleoutputdimensions[1]:
            continue
        for rowoffset in range(puzzleoutputdimensions[0]-outputdimensions[0]+1):
            for columnoffset in range(puzzleoutputdimensions[1]-outputdimensions[1]+1):
                newoutput = {(cell[0]+rowoffset,cell[1]+columnoffset):output[cell] for cell in output}
                for cell in newoutput:
                    if newoutput[cell][0] > puzzleoutput.get(cell,(-float("inf"),))[0] or newoutput[cell][1] > puzzleoutput.get(cell,(0,-float("inf")))[1]:
                        break
                else:
                    return True
    return False